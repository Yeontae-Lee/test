<%@page import="java.util.ArrayList"%>
<%@page import="board.FileBoardDTO"%>
<%@page import="board.FileBoardDAO"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>center/driver.jsp</title>
<link href="../css/default.css" rel="stylesheet" type="text/css">
<link href="../css/subpage.css" rel="stylesheet" type="text/css">
</head>
<body>
	<div id="wrap">
		<!-- 헤더 들어가는곳 -->
		<jsp:include page="../inc/top.jsp" />
		<!-- 헤더 들어가는곳 -->

		<!-- 본문들어가는 곳 -->
		<!-- 본문 메인 이미지 -->
		<div id="sub_img_center"></div>
		<!-- 왼쪽 메뉴 -->
		<nav id="sub_menu">
			<ul>
				<li><a href="./notice.jsp">Notice</a></li>
				<li><a href="#">Public News</a></li>
				<li><a href="./driver.jsp">Driver Download</a></li>
				<li><a href="#">Service Policy</a></li>
			</ul>
		</nav>
		<!-- 본문 내용 -->
		<article>
			<h1>Driver Download</h1>
			<table id="notice">
				<tr>
					<th class="tno">No.</th>
					<th class="ttitle">Title</th>
					<th class="twrite">Writer</th>
					<th class="tdate">Date</th>
					<th class="tread">Read</th>
				</tr>
				<%
				// FileBoardDAO 객체를 활용하여 게시물 목록 가져오기
				FileBoardDAO fileBoardDAO = new FileBoardDAO();
				// FileBoardDAO 객체의 selectFileBoardList() 메서드를 호출하여 게시물 목록 리턴받기
				// => 파라미터 : 없음    리턴타입 : ArrayList<FileBoardDTO>
				ArrayList<FileBoardDTO> fileBoardList = fileBoardDAO.selectFileBoardList();
				
				// ArrayList 객체가 null 이 아니고, 저장된 객체가 1개 이상일 때만 목록 출력
				if(fileBoardList != null && fileBoardList.size() > 0) {
					for(FileBoardDTO fileBoard : fileBoardList) {
						%>
						<tr onclick="location.href='./driver_content.jsp?num=<%=fileBoard.getNum() %>'">
							<td><%=fileBoard.getNum() %></td>
							<td class="left"><%=fileBoard.getSubject() %></td>
							<td><%=fileBoard.getName() %></td>
							<td><%=fileBoard.getDate() %></td>
							<td><%=fileBoard.getReadcount() %></td>
						</tr>
						<%
					}
				} else {
				%>
				<!-- 게시물 목록이 없을 경우 -->
				<tr>
					<td colspan="5">작성된 게시물이 없습니다.</td>
				</tr>
				<%} %>
			</table>
			<div id="table_search">
				<input type="button" value="글쓰기" class="btn" 
						onclick="location.href='./driver_write.jsp'">
			</div>
			<div id="table_search">
				<form action="#" method="post">
					<input type="text" name="search" class="input_box">
					<input type="submit" value="Search" class="btn">
				</form>
			</div>

			<div class="clear"></div>
			<div id="page_control">
				<a href="#">Prev</a>
				<a href="#">1</a><a href="#">2</a><a href="#">3</a>
				<a href="#">Next</a>

			</div>
		</article>

		<div class="clear"></div>
		<!-- 푸터 들어가는곳 -->
		<jsp:include page="../inc/bottom.jsp" />
		<!-- 푸터 들어가는곳 -->
	</div>
</body>
</html>


